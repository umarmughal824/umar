from setuptools import setup, find_packages


setup(
    name="umar",
    version="0.1.0",
    packages=find_packages(),
    description="A simple example package",
    author="Umar Asghar",
    author_email="mrumarasghar@gmail.com",
    url="https://github.com/UmarAsghar/umar",
)
